 import React from 'react';
 import { BrowserRouter, Routes, Route } from 'react-router-dom';

 import Navbar from './components/Navbar';
 import SearchPage from './pages/SearchPage';
 import DetailsPage from './pages/DetailsPage';
 import FavoritesPage from './pages/FavoritesPage';

 export default function App() {
   return (
     <BrowserRouter>
-      {/* wrong: navbar here would be scoped to container width */}
-      {/* <div className="container mt-4"> */}
-        <Navbar />
-        <Routes>…
-        </Routes>
-      {/* </div> */}
+      {/* navbar lives *outside* the container so it spans the full viewport */}
+      <Navbar />

+      {/* all page content stays inside the centered container */}
+      <div className="container mt-4">
+        <Routes>
+          <Route path="/"             element={<SearchPage />}   />
+          <Route path="/employee/:id" element={<DetailsPage />} />
+          <Route path="/favorites"    element={<FavoritesPage />} />
+        </Routes>
+      </div>
     </BrowserRouter>
   );
 }
