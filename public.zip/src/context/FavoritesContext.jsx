// Project: advanced-react-employees-app

// Folder Structure:
// advanced-react-employees-app/
// ├ public/
// │  └ index.html
// ├ src/
// │  ├ context/
// │  │  ├ ApiConfigContext.jsx
// │  │  └ FavoritesContext.jsx
// │  ├ services/
// │  │  └ apiService.js
// │  ├ hooks/
// │  ├ pages/
// │  ├ components/
// │  └ main.jsx
// ├ .eslintrc.js
// ├ vite.config.js
// ├ package.json
// └ README.md

/* public/index.html */

<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Employees App</title>

  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-..."
    crossorigin="anonymous"
  />
 
  <link
    rel="stylesheet"
    href="https://unpkg.com/leaflet/dist/leaflet.css"
  />
</head>
<body>
  <div id="root"></div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
</body>
</html>

/* src/context/ApiConfigContext.jsx */
import React, { createContext } from 'react';

export const ApiConfigContext = createContext({
  baseUrl: 'https://randomuser.me/api',
  seed: 'google',
});

export const ApiConfigProvider = ({ children }) => (
  <ApiConfigContext.Provider value={{ baseUrl: 'https://randomuser.me/api', seed: 'google' }}>
    {children}
  </ApiConfigContext.Provider>
);

/* src/context/FavoritesContext.jsx */
import React, { createContext, useState, useEffect } from 'react';

export const FavoritesContext = createContext();

export const FavoritesProvider = ({ children }) => {
  const [favs, setFavs] = useState(() => {
    const saved = localStorage.getItem('FAVS');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('FAVS', JSON.stringify(favs));
  }, [favs]);

  return (
    <FavoritesContext.Provider value={{ favs, setFavs }}>
      {children}
    </FavoritesContext.Provider>
  );
};

/* src/services/apiService.js */
export async function fetchEmployees(seed = 'google') {
  const url = `https://randomuser.me/api/?results=10&seed=${seed}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('API error');
  const data = await res.json();
  return data.results;
}

/* src/main.jsx */
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.jsx';
import './index.css';
import { ApiConfigProvider } from './context/ApiConfigContext.jsx';
import { FavoritesProvider } from './context/FavoritesContext.jsx';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <ApiConfigProvider>
      <FavoritesProvider>
        <App />
      </FavoritesProvider>
    </ApiConfigProvider>
  </React.StrictMode>
);

/* .eslintrc.js (from lessons) */
module.exports = {
  parser: '@babel/eslint-parser',
  extends: ['eslint:recommended', 'plugin:react/recommended'],
  settings: { react: { version: 'detect' } },
  env: { browser: true, es2021: true },
  rules: { 'react/prop-types': 'off' },
};
