import React from 'react';

export default function SearchPage() {
  return <h1>Search Page</h1>;
}
