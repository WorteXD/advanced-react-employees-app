import React from 'react';
import { useParams } from 'react-router-dom';

export default function DetailsPage() {
  const { id } = useParams();
  return <h1>Details Page for employee {id}</h1>;
}
