import React from 'react';

export default function FavoritesPage() {
  return <h1>Favorites Page</h1>;
}
